<?php

/**
 * @Author: Administrator
 * @Date:   2019-10-12 14:12:13
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-10-14 13:50:03
 */

//清空文件夹函数和清空文件夹后删除空文件夹函数的处理
function deldir($path){
   //如果是目录则继续
  if(is_dir($path)){
      //扫描一个文件夹内的所有文件夹和文件并返回数组
    $p = scandir($path);
    foreach($p as $val){
      //排除目录中的.和..
      if($val !="." && $val !=".."){
        //如果是目录则递归子目录，继续操作
        if(is_dir($path.$val)){
          //子目录中操作删除文件夹和文件
          deldir($path.$val.'/');
          //目录清空后删除空文件夹
          @rmdir($path.$val.'/');
        }else{
          //如果是文件直接删除
          unlink($path.$val);
        }
      }
    }
    // 删除文件夹
    rmdir($path);
  }
}

$fileId = $_POST['id'];
// 临时文件夹名称
$length = strlen($fileId) - (strlen($fileId) - strpos($fileId, '.'));
$filedir = substr($fileId, 0, $length);

$size = $_POST['size'];
$file = './upload/' . $fileId;
$flag = true;

// 创建最终文件
if(!file_exists($file)){
  // 最终文件不存在，创建文件
  $myfile = fopen($file, 'w+');
  fclose($myfile);
} 
// 用增加方式打开最终文件
$myfile = fopen($file, 'a');

for ($i = 0; $i < $size; $i++) {
  // 单文件路径
  $filePart = 'upload/' . $filedir . '/' . $i;

  if(file_exists($filePart)){
    $chunk = file_get_contents($filePart);
    // 写入chunk
    fwrite($myfile, $chunk);
  } else{
    echo "缺少Part$i 文件，请重新上传";
    $flag = false;
    break;
  }
}

fclose($myfile);
echo "整合完成";
if(flag){
   //删除临时文件夹
  deldir("upload/$filedir/");
}



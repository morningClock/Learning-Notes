<?php

/**
 * @Author: Administrator
 * @Date:   2019-10-14 09:20:15
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-10-14 11:49:21
 */

// 1.检测数据文件是否存在(文件标识，数据段总数)
$fileId = $_POST['id'];
$size = $_POST['size'];
// 临时文件夹名称
$length = strlen($fileId) - (strlen($fileId) - strpos($fileId, '.'));
$filedir = substr($fileId, 0, $length);

// 2.按顺序检测缺失的数据段的位置
// 检测是否存在文件夹
if (is_dir("upload/$filedir")) {
  $offset = $size;
  // 检测数据段缺失下标
  for ($i = 0; $i < $size; $i++) {
    $filepath = "upload/$filedir/$i";
    if(!file_exists($filepath)){
      // 缺失i部分
      $offset = $i;
      break;
    }
  }
  // 输出偏移量
  echo $offset;
} 
else {
  // 是否存在已合并文件
  if(file_exists("upload/$fileId")){
    echo $size;
  } else{
    // 文件尚未上传
    echo 0;
  }
}
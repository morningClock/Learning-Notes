<?php

/**
 * @Author: Administrator
 * @Date:   2019-10-11 16:09:45
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-10-12 16:54:15
 */
if(!is_dir('upload')){
  mkdir('upload', 0777);
}

$chunk = $_FILES['myFileChunk'];
// 文件唯一标识
$fileId = $_POST['fileId'];
// 临时文件夹名称
$length = strlen($fileId) - (strlen($fileId) - strpos($fileId, '.'));
$filedir = substr($fileId, 0, $length);

$chunkIndex = $_POST['chunkIndex'];

$filepath = 'upload/' . $filedir;

$filename = $filepath . '/' . $chunkIndex;

if(!is_dir($filepath)){
  mkdir($filepath, 0777);
}
move_uploaded_file($chunk['tmp_name'], $filename);

echo $chunkIndex;
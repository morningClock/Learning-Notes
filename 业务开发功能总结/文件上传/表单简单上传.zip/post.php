<?php

/**
 * @Author: Administrator
 * @Date:   2019-10-11 16:09:45
 * @Last Modified by:   Administrator
 * @Last Modified time: 2019-10-12 09:55:58
 */

function random_str($length)
{
    //生成一个包含 大写英文字母, 小写英文字母, 数字 的数组
  $arr = array_merge(range(0, 9), range('a', 'z'), range('A', 'Z')); 
  $str = '';
  $arr_len = count($arr);
  for ($i = 0; $i < $length; $i++)
  {
    $rand = mt_rand(0, $arr_len-1);
    $str.=$arr[$rand];
  } 
  return $str;
}

$myfile = $_FILES['myfile'];
//截取文件后缀名
$type = strrchr($myfile['name'], ".");
//设置上传路径，我把它放在了upload下的interview目录下（需要在linux中给interview设置文件夹权限）
$path = "upload/" . $myfile['name']; 
// tmp_name临时存储文件
if(move_uploaded_file($myfile['tmp_name'], $path)){
  echo "上传成功";
} else{
  echo "上传失败";
};
